//
//  MainWindowController.m
//  MacOSTencentVideoPlayerDemo
//
//  Created by derek on 2019/1/19.
//  Copyright © 2019年 derek. All rights reserved.
//

#import "MainWindowController.h"

@interface MainWindowController ()<NSWindowDelegate>

@property (nonatomic,strong)NSScrollView *scrollView;
@property (nonatomic,strong)NSView *contentView;
@property (nonatomic,strong)NSArray *titleArr;
@property (nonatomic,assign)CGRect s_frame;
@property (nonatomic,strong)NSButton *selectedBTN;

@end

@implementation MainWindowController

- (void)windowDidLoad {
    [super windowDidLoad];
    
    // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
    //监控window变化
    self.window.delegate = self;
    [self.window center];
    self.window.maxSize = NSMakeSize(1280, 800);
    self.window.minSize = NSMakeSize(1080, 720);
    
    self.window.backgroundColor = [NSColor colorWithRed:58/255.0 green:60/255.0 blue:64/255.0 alpha:1];
    

    self.titleArr = @[@"眼界",@"游戏 ",@"韩剧",@"英剧",@"美剧",@"NBA",@"体育",@"新闻",@"娱乐",@"王者荣耀",@"微电影",@"爱看",@"音乐",@"海外剧",@"纪录片",@"少儿",@"动漫",@"综艺",@"首页"];
    
    CGRect s_frame = CGRectMake(0, 0, 100, self.window.frame.size.height - 40);
    self.s_frame = s_frame;
    BOOL less_Num = YES;
    if (self.titleArr.count * 20 > self.window.frame.size.height - 40) {
        s_frame = CGRectMake(0, 0, 100, self.titleArr.count * 20);
        less_Num = NO;//多
    }else{
        s_frame = CGRectMake(0, 0, 100, self.window.frame.size.height - 40);
        less_Num = YES;//少
    }
    
    NSScrollView *scrollView = [[NSScrollView alloc] initWithFrame:CGRectMake(0, 0, 100, self.window.frame.size.height - 40)];
    self.scrollView = scrollView;
    
    scrollView.backgroundColor = [NSColor blackColor];
    [self.window.contentView addSubview:scrollView];
    
    scrollView.hasHorizontalScroller = NO;
    
    //相当于contenSize
    NSView *contentView = [[NSView alloc] initWithFrame:s_frame];
    self.contentView = contentView;
    scrollView.documentView = contentView;
    
    //垂直方向的滚动条
    NSScroller *scroller = [[NSScroller alloc] initWithFrame:CGRectMake(0, 0, 20, 10)];
    scrollView.verticalScroller = scroller;
    [scroller setScrollerStyle:NSScrollerStyleOverlay];
    
    int y = 0;
    for (int i = 0; i < self.titleArr.count; i++) {
        
        if (less_Num == YES) {
            y = self.window.frame.size.height - 40 - self.titleArr.count * 20 + i * 20;
        }else{
            y = i * 20;
        }
        NSButton *bt = [[NSButton alloc] initWithFrame:CGRectMake(0,y, 100, 20)];
        bt.bezelStyle = NSBezelStyleRecessed;
        [bt setTitle:[NSString stringWithFormat:@"%@",self.titleArr[i]]];
        bt.tag = i;
        //bt.transparent = NO;
        bt.state = NSControlStateValueMixed;
        //bt.image = [NSImage imageNamed:@"selectLine"];
        bt.imageScaling = NSImageScaleProportionallyUpOrDown;
        bt.imagePosition = NSImageLeft;
        [contentView addSubview:bt];
        
        [bt setTarget:self];
        bt.action = @selector(clickBtn:);
    }
    
    if (less_Num == NO) {
        [[scrollView contentView] scrollToPoint:CGPointMake(0, (self.titleArr.count * 20 - (self.window.frame.size.height - 40)))];
    }
}

- (NSString *)windowNibName{
    return @"MainWindowController";
}

- (void)windowDidResize:(NSNotification *)notification{
    
    NSLog(@"----999999 ------" );
    // 根据需要调整NSView上面的别的控件和视图的frame
    self.scrollView.frame = CGRectMake(0, 0, 100, self.window.frame.size.height - 40);
}

- (void)clickBtn:(NSButton *)btn{
    NSLog(@"---%@------",btn.title);
    
//    if (btn.accessibilitySelected == YES) {
//        [btn setImage:[NSImage imageNamed:@"selectLine"]];
//    }else{
//        self.selectedBTN = btn;
//    }
    
    if (btn!= self.selectedBTN) {
        self.selectedBTN.accessibilitySelected = NO;
        btn.accessibilitySelected = YES;
        [btn setImage:[NSImage imageNamed:@"selectLine"]];
        self.selectedBTN = btn;
    }else{
        self.selectedBTN.accessibilitySelected = YES;
        [self.selectedBTN setImage:nil];
    }
}

@end
