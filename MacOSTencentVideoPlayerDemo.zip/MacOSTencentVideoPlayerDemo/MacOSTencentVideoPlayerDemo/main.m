//
//  main.m
//  MacOSTencentVideoPlayerDemo
//
//  Created by derek on 2019/1/19.
//  Copyright © 2019年 derek. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
