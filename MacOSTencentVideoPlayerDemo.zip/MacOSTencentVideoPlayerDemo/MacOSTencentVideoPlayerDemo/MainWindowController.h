//
//  MainWindowController.h
//  MacOSTencentVideoPlayerDemo
//
//  Created by derek on 2019/1/19.
//  Copyright © 2019年 derek. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface MainWindowController : NSWindowController

@end

NS_ASSUME_NONNULL_END
