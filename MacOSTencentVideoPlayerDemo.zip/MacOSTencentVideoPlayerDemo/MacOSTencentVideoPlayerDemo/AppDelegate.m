//
//  AppDelegate.m
//  MacOSTencentVideoPlayerDemo
//
//  Created by derek on 2019/1/19.
//  Copyright © 2019年 derek. All rights reserved.
//

#import "AppDelegate.h"
#import "MainWindowController.h"

@interface AppDelegate ()

@property(nonatomic,strong)MainWindowController *mainWindowController;

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
    [self.mainWindowController showWindow:self];
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}

- (MainWindowController *)mainWindowController{
    if (!_mainWindowController) {
        _mainWindowController = [[MainWindowController alloc] init];
    }
    return _mainWindowController;
}

@end
